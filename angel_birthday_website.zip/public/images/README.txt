Optional: place image files (image1.jpg, image2.jpg...) here for offline use.
