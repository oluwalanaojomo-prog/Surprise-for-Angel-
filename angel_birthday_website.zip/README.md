Surprise for my Angel — Ready-to-Deploy React App
=================================================

This ZIP contains a ready-to-deploy React project (Vite) with the interactive birthday website.
**IMPORTANT:** I cannot automatically download files from your Google Drive inside this environment.
To make the site work offline (and to embed the audio/music), please follow the steps below.

Files of note:
 - src/App.jsx         — main React component with the full site code and animations.
 - public/music/      — place your MP3 files here for offline/embedded playback.
 - public/images/     — optional: place image copies here for offline use (otherwise Drive URLs will be used).
 - README.md           — this file.
 - deploy-steps.txt    — step-by-step Vercel deploy guide.

How to prepare (offline & online ready)
---------------------------------------
1. Download the three MP3 files you supplied (from Google Drive) to your computer:
   - https://drive.google.com/file/d/1tzD8RsH0-aLnAOiLWUTzIR8Hnstf6Zya/view
   - https://drive.google.com/file/d/1n4JhQGnDyj4vv2kOHmwo51aCcl-TYHra/view
   - https://drive.google.com/file/d/19cyJylHrME5LOFKx4cDsqU9fZNKtjCaM/view

2. Place those MP3 files in this project's `public/music/` folder and rename them exactly to:
   - track1.mp3
   - track2.mp3
   - track3.mp3

3. (Optional) Download the images and place them in `public/images/` using names like image1.jpg, image2.jpg, ...

4. If you place assets in `public/`, the site will use local files (works offline).
   Otherwise the site uses the Google Drive direct-view links embedded in the code (needs internet).

Run locally (to preview):
-------------------------
1. Install Node.js (v18+) and npm.
2. Open a terminal in the project folder.
3. Run:
   npm install
   npm run dev
4. Open http://localhost:5173 in your browser.

Deploy to Vercel (quick):
-------------------------
1. Create a free account at https://vercel.com
2. From the Vercel dashboard, choose "New Project" → "Import from Git" or upload the ZIP.
   - To upload ZIP: go to https://vercel.com/new and choose "Import Project" then drag & drop this project folder.
3. Vercel will build and provide a live link (e.g. https://angel-birthday.vercel.app).

Notes:
 - Autoplay policies: Most browsers require a user interaction for unmuted autoplay. The site includes an intro envelope click to ensure audio starts smoothly.
 - If you want me to produce a version that automatically fetches your Drive files when you run a script locally, I can provide that script — but you'll need to run it from your own machine.

If you want, after you download this ZIP and place the MP3 files into public/music, paste back here and I will:
 - give exact commands to upload to Vercel and set it live,
 - or update the code to point to any other hosting you prefer.