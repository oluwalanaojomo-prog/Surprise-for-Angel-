import React, { useEffect, useState, useRef } from "react";
import confetti from "canvas-confetti";
import { motion, AnimatePresence } from "framer-motion";

export default function BirthdayPage() {
  const herName = "Angel";
  const fromName = "Levin";
  const nicknames = ["my love", "Narci", "my baby"];

  const [photos, setPhotos] = useState([
    // Local fallbacks: if you place images in public/images, uncomment and use:
    // "/images/image1.jpg", "/images/image2.jpg", ...
    "https://drive.google.com/uc?export=view&id=1XPXmC1iXKAFQgCUwiuvny8qZYv7rQXQD",
    "https://drive.google.com/uc?export=view&id=1-IhGvO-_1bsQKA6gUfWlNCvtDKSI69Wy",
    "https://drive.google.com/uc?export=view&id=1vZVQtXX8vsSDH8djHWSt3INA4vtOIuN8",
    "https://drive.google.com/uc?export=view&id=1MAr-mJW2eIidmR4cOGrHSqFspWkNJrR4",
    "https://drive.google.com/uc?export=view&id=1M_e4YlwUL0lpOUo16usk1Mnf_w421tmE",
    "https://drive.google.com/uc?export=view&id=1kPCA_rWgalOO02_sj7yHAtY5KvmFAePH",
    "https://drive.google.com/uc?export=view&id=16bVxU-bUbpbKCI46ob-Ooo2E1WRKriuR",
    "https://drive.google.com/uc?export=view&id=1P985XDvoRKNflqamdI76qn5J9ueXjFAb"
  ]);

  const [currentSection, setCurrentSection] = useState(0);
  const [showAdmin, setShowAdmin] = useState(false);
  const [newPhotoUrl, setNewPhotoUrl] = useState("");
  const [note, setNote] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [introVisible, setIntroVisible] = useState(true);
  const [envelopeOpened, setEnvelopeOpened] = useState(false);
  const audioRefs = useRef([]);

  const messages = [
    `Happy Birthday, ${nicknames[0]} — you’re fine asffff, birthday girlll 😍💋`,
    `You’re literally the most beautiful thing in the universe ✨`,
    `I still can’t believe I get to call you mine, ${nicknames[1]}. 💖`,
    `I love you — more than I can ever explain, ${nicknames[2]}.`,
    `You glow brighter than every star in this sky 🌌`,
    `Your laugh? My favorite song.`,
    `You’re magic. You’re peace. You’re everything.`,
    `Keep being the light that makes life worth living 💫`,
    `Happy Birthday, Angel — you’re my whole world 💐💗`
  ];

  const songSources = [
    // If you place MP3s in public/music, these local paths will be used automatically.
    "/music/track1.mp3",
    "/music/track2.mp3",
    "/music/track3.mp3"
  ];

  // initialize audio refs
  useEffect(() => {
    audioRefs.current = songSources.map((_, i) => audioRefs.current[i] ?? React.createRef());
  }, []);

  useEffect(() => {
    // Try to play muted audios to satisfy browser autoplay policies
    const tryPlay = async () => {
      try {
        for (let i = 0; i < songSources.length; i++) {
          const a = audioRefs.current[i]?.current;
          if (a) {
            a.volume = 0;
            await a.play().catch(() => {});
          }
        }
      } catch (e) {}
    };
    tryPlay();
  }, []);

  const crossfadeTo = (targetIndex) => {
    if (!audioRefs.current.length) return;
    const fadeDuration = 1200;
    const steps = 30;
    const stepTime = fadeDuration / steps;
    audioRefs.current.forEach((r) => { if (r.current && r.current.paused) r.current.play().catch(()=>{}); });
    let step = 0;
    const startVolumes = audioRefs.current.map((r) => (r.current ? r.current.volume : 0));
    const targetVolumes = audioRefs.current.map((_, i) => (i === targetIndex ? 0.9 : 0));
    const interval = setInterval(() => {
      step++;
      for (let i = 0; i < audioRefs.current.length; i++) {
        const a = audioRefs.current[i].current;
        if (!a) continue;
        const sv = startVolumes[i];
        const tv = targetVolumes[i];
        const nv = sv + ((tv - sv) * step) / steps;
        a.volume = Math.max(0, Math.min(1, nv));
      }
      if (step >= steps) clearInterval(interval);
    }, stepTime);
  };

  const triggerConfetti = (heart=false) => {
    const duration = 2500;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 1000 };
    const interval = setInterval(function () {
      const timeLeft = animationEnd - Date.now();
      if (timeLeft <= 0) return clearInterval(interval);
      const particleCount = 40 * (timeLeft / duration);
      confetti({
        ...defaults,
        particleCount: particleCount,
        origin: { x: Math.random(), y: Math.random() - 0.2 },
        colors: heart ? ["#ff6b9a","#ffb3c6","#ff7ca3"] : undefined
      });
    }, 250);
  };

  const songForSection = (idx) => Math.min(songSources.length - 1, Math.floor((idx / Math.max(1, Math.ceil(photos.length / songSources.length))) * songSources.length));

  const handleEnvelopeOpen = async () => {
    setEnvelopeOpened(true);
    for (let i = 0; i < audioRefs.current.length; i++) {
      const a = audioRefs.current[i].current;
      if (a) { try { await a.play(); } catch(e){} a.volume = 0; }
    }
    // fade first track in
    const fadeDuration = 2000;
    const steps = 40;
    const stepTime = fadeDuration / steps;
    let step = 0;
    const interval = setInterval(() => {
      step++;
      const vol = (0.9 * step) / steps;
      const a0 = audioRefs.current[0]?.current;
      if (a0) a0.volume = vol;
      if (step >= steps) clearInterval(interval);
    }, stepTime);

    triggerConfetti(true);
    setTimeout(() => { setIntroVisible(false); setIsPlaying(true); const first = document.querySelector('.moment-section'); if(first) first.scrollIntoView({behavior:'smooth'}); }, 3500);
  };

  const handleUserPlay = async () => {
    for (let i = 0; i < audioRefs.current.length; i++) {
      const a = audioRefs.current[i].current;
      if (a) { try{ await a.play(); }catch(e){} a.volume = i===0?0.9:0; }
    }
    setIsPlaying(true);
    if (introVisible && !envelopeOpened) { setTimeout(() => handleEnvelopeOpen(), 300); }
  };

  useEffect(() => {
    const sections = Array.from(document.querySelectorAll('.moment-section'));
    if (!sections.length) return;
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const idx = Number(entry.target.getAttribute('data-idx'));
          setCurrentSection(idx);
          const part = songForSection(idx);
          crossfadeTo(part);
        }
      });
    }, { threshold: 0.6 });
    sections.forEach((s) => io.observe(s));
    return () => io.disconnect();
  }, [photos]);

  const addPhoto = () => {
    if (newPhotoUrl.trim()) {
      setPhotos((p)=>[...p,newPhotoUrl.trim()]);
      setNewPhotoUrl('');
    }
  };

  return (
    <div className="relative min-h-screen text-white font-sans overflow-x-hidden">
      <div className="fixed inset-0 -z-20 bg-gradient-to-b from-[#030515] via-[#07102a] to-[#031226]">
        <div className="absolute inset-0 stars" />
        <div className="absolute inset-0 starfield" aria-hidden />
      </div>

  <div style={{display:'none'}}>
    {songSources.map((src,i)=>(
      <audio key={i} ref={(el)=>(audioRefs.current[i]={current:el})} src={src} loop />
    ))}
  </div>

  <AnimatePresence>
    {introVisible && (
      <motion.div initial={{opacity:1}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 flex items-center justify-center bg-black/80">
        <div className="text-center px-6">
          {!envelopeOpened ? (
            <>
              <motion.h2 initial={{opacity:0,scale:0.95}} animate={{opacity:1,scale:1}} transition={{duration:1}} className="text-3xl md:text-4xl font-bold mb-6">
                <span className="opacity-90">Loading</span><span className="animate-pulse">…</span><br/> <span className="text-pink-300">Angel ✨</span>
              </motion.h2>

              <motion.div initial={{y:40,opacity:0}} animate={{y:0,opacity:1}} transition={{delay:0.6}}>
                <motion.button whileHover={{scale:1.03}} whileTap={{scale:0.98}} onClick={handleEnvelopeOpen} className="relative mx-auto w-40 h-28 bg-gradient-to-br from-pink-500 to-pink-400 rounded-xl shadow-2xl flex items-center justify-center">
                  <div className="absolute -top-6 w-14 h-14 rounded-full bg-pink-200 flex items-center justify-center shadow-md">
                    <div className="text-pink-700 text-xl">❤</div>
                  </div>
                  <div className="text-white font-semibold">Open my letter</div>
                </motion.button>
                <p className="mt-4 text-white/70 text-sm">Tap the envelope to read your message.</p>
              </motion.div>
            </>
          ) : (
            <motion.div initial={{opacity:0,scale:0.95}} animate={{opacity:1,scale:1}} transition={{duration:0.6}}>
              <div className="max-w-xl bg-black/50 p-6 rounded-xl shadow-xl">
                <h3 className="text-xl font-bold mb-3">Hiii Angel, my love 💖</h3>
                <p className="text-white/90 mb-4">Happy Birthday to the most beautiful soul in the universe 💫<br/>You’re fine asffff birthday girlll 😍</p>
                <div className="flex gap-3 justify-center">
                  <button onClick={() => { triggerConfetti(true); setTimeout(() => { setIntroVisible(false); const first = document.querySelector('.moment-section'); if (first) first.scrollIntoView({ behavior: 'smooth' }); setIsPlaying(true); }, 1200); }} className="px-4 py-2 rounded-full bg-pink-600 text-white">Send Love</button>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>
    )}
  </AnimatePresence>

  <header className="pt-6 pb-4 text-center z-10">
    <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight drop-shadow-lg">Happy Birthday, {herName} 🎉</h1>
    <p className="mt-1 text-white/80">From {fromName} — a story for you, one scroll at a time.</p>
  </header>

  <button onClick={() => setShowAdmin(!showAdmin)} className="fixed top-4 right-4 z-40 bg-white/5 hover:bg-white/10 text-white text-sm px-2 py-1 rounded-full">⚙️</button>

  {showAdmin && (
    <div className="fixed top-16 right-4 bg-black/70 p-4 rounded-lg z-50 border border-white/10 w-80">
      <h3 className="text-lg font-semibold mb-2">Admin Upload Panel</h3>
      <p className="text-sm text-white/70 mb-2">Paste an image URL below and click Add.</p>
      <input type="url" placeholder="https://..." value={newPhotoUrl} onChange={(e)=>setNewPhotoUrl(e.target.value)} className="w-full p-2 rounded bg-white/5 mb-2 text-white text-sm" />
      <div className="flex gap-2">
        <button onClick={addPhoto} className="bg-pink-600 hover:bg-pink-700 rounded py-2 px-3 text-sm">Add Image</button>
        <button onClick={() => { navigator.clipboard.writeText(photos.join('\\n')); }} className="bg-white/5 rounded py-2 px-3 text-sm">Copy URLs</button>
      </div>
    </div>
  )}

  <main className="flex flex-col items-center">
    {photos.map((p,idx)=>(
      <section key={idx} data-idx={idx} className="moment-section w-full min-h-screen flex items-center justify-center px-6 py-12" style={{scrollSnapAlign:'start'}}>
        <div className="max-w-5xl w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="photo-card relative rounded-3xl overflow-hidden shadow-2xl border border-white/10" style={{minHeight:420}}>
            <img src={p} alt={`Angel ${idx+1}`} className="w-full h-full object-cover transform transition-transform duration-900 ease-out scale-100 hover:scale-105"/>
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"/>
            <div className="absolute top-4 right-4 text-sm bg-black/40 px-3 py-1 rounded-full">{idx+1}/{photos.length}</div>
          </div>

          <div className="text-panel text-white/95">
            <h3 className="text-2xl font-bold mb-3">{idx===photos.length-1?`Final Surprise`:`Memory ${idx+1}`}</h3>
            <p className="mb-6 text-lg">{messages[idx % messages.length]}</p>
            <div className="mb-4 text-sm text-white/70">Nickname: <span className="font-semibold">{nicknames[idx % nicknames.length]}</span></div>
            <div className="flex gap-3">
              <button onClick={()=>{ setNote(messages[idx % messages.length]); triggerConfetti(true); }} className="relative inline-block px-5 py-3 rounded-full bg-gradient-to-r from-pink-600 to-pink-400 text-white font-semibold shadow-lg glow-btn">Reveal Love</button>
              <button onClick={()=>{ triggerConfetti(true); }} className="inline-block px-4 py-3 rounded-full bg-white/5 text-white">Celebrate</button>
            </div>
          </div>
        </div>
      </section>
    ))}

    <section className="w-full min-h-screen flex items-center justify-center px-6 py-12 moment-section" data-idx={photos.length}>
      <div className="max-w-3xl text-center">
        <div className="mx-auto relative w-64 h-48">
          <div className="absolute inset-0 rounded-2xl bg-pink-700/20 backdrop-blur-sm shadow-inner"/>
          <div className="absolute left-1/2 transform -translate-x-1/2 -top-6 flex space-x-3 z-20">
            {Array.from({length:5}).map((_,i)=>(
              <div key={i} className="w-1 h-10 bg-yellow-200 rounded-sm animate-flicker"/>
            ))}
          </div>
          <div className="absolute inset-0 flex items-center justify-center z-30">
            <div className="cake-shadow rounded-2xl p-6">
              <div className="cake-core bg-pink-500 rounded-xl p-6 text-white font-semibold">Make a Wish 🎂</div>
            </div>
          </div>
        </div>

        <div className="mt-8">
          <button onClick={()=>{ setNote(messages[photos.length % messages.length]); triggerConfetti(true); }} className="px-7 py-3 rounded-full bg-gradient-to-r from-pink-600 to-pink-400 text-white font-bold shadow-xl glow-btn-lg">Make a Wish ✨</button>
        </div>

        <p className="mt-6 text-white/80">You’re my forever, Angel. I love you so much 💗</p>
        <p className="mt-2 text-sm text-white/70">From Levin 💌 — All for my baby.</p>
      </div>
    </section>
  </main>

  <footer className="py-8 text-center text-white/60">© 2025 Made with ❤️ by {fromName} • Oct 24</footer>

  <style>{`
    html, body, #root { height: 100%; }
    main { scroll-snap-type: y mandatory; }
    .stars { background-image: radial-gradient(circle at 10% 20%, rgba(255,255,255,0.9) 1px, transparent 1px), radial-gradient(circle at 40% 80%, rgba(255,255,255,0.75) 1px, transparent 1px), radial-gradient(circle at 70% 30%, rgba(255,255,255,0.6) 1px, transparent 1px); background-size: 600px 600px, 400px 400px, 700px 700px; opacity:0.9; }
    .starfield { background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800"><defs><radialGradient id="g" cx="50%" cy="50%"><stop offset="0%" stop-color="white" stop-opacity="0.9"/><stop offset="100%" stop-color="white" stop-opacity="0"/></radialGradient></defs><g fill="url(%23g)"><circle cx="50" cy="40" r="1"/><circle cx="200" cy="80" r="1"/><circle cx="400" cy="20" r="1"/><circle cx="600" cy="140" r="1"/><circle cx="800" cy="60" r="1"/><circle cx="1000" cy="120" r="1"/></g></svg>'); background-repeat: repeat; opacity:0.25; }
    .glow-btn { box-shadow: 0 6px 20px rgba(219,39,119,0.18); position: relative; }
    .glow-btn::after { content: ''; position: absolute; inset: -6px; border-radius: 999px; background: radial-gradient(circle at 30% 20%, rgba(255,255,255,0.06), transparent 20%), radial-gradient(circle at 70% 80%, rgba(255,255,255,0.04), transparent 30%); pointer-events:none; }
    .glow-btn-lg { position: relative; box-shadow: 0 12px 40px rgba(219,39,119,0.22); }
    .glow-btn-lg::before { content: ''; position: absolute; left: -10px; right: -10px; top: -10px; bottom: -10px; border-radius: 999px; background: radial-gradient(circle, rgba(255,182,193,0.06), transparent 30%); filter: blur(8px); opacity: 0.9; }
    .cake-shadow { filter: drop-shadow(0 8px 40px rgba(219,39,119,0.12)); }
    .animate-flicker { animation: flicker 1.5s infinite; }
    @keyframes flicker { 0%,100%{opacity:1}50%{opacity:0.3} }
    img { transition: opacity 0.9s ease, transform 1s ease; }
    .animate-pulse { animation: pulse 1.4s infinite; }
    @keyframes pulse { 0%{opacity:0.6}50%{opacity:1}100%{opacity:0.6} }
  `}</style>
</div>
);
}
